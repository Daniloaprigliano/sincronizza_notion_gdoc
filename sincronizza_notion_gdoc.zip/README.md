# sincronizza_notion_gdoc

Pagina pubblica per avviare manualmente la sincronizzazione tra Notion e Google Docs via GitHub Actions.